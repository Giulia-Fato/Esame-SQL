CREATE	database	TOYSS_GROUP;
USE	TOYS_GROUP;
CREATE	TABLE	CATEGORIES	(
CATEGORYID	INT	PRIMARY KEY,
CATEGORYNAME	VARCHAR	(20)
);
INSERT	INTO	CATEGORIES	(CATEGORYID,CATEGORYNAME)	VALUES
(1, 'Giocattoli'),
(2, 'Elettronica'),
(3, 'Abbigliamento'),
(4, 'Gioielli'),
(5, 'Profumeria'),
(6, 'Sport'),
(7, 'Società'),
(8, 'Scienza e natura'),
(9, 'Per bambini'),
(10, 'Magia');

CREATE TABLE Regions (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR	(20)
    );
    
INSERT	INTO	Regions	(RegionID,	RegionName)	values
(1, 'Ovest Europa'),
(2, 'Sud Europa'),
(3, 'Nord Europa'),
(4, 'Est Europa'),
(5, 'Africa'),
(7, 'Asia'),
(8, 'Nord America'),
(9, 'Sud America'),
(10, 'Oceania');

CREATE TABLE	PRODUCTS(
ProductID	INT	PRIMARY	KEY,
PRODUCTNAME	VARCHAR(50),
CATEGORYID	INT,
PRICE	DECIMAL	(7,2),
manufactured varchar(50),
foreign key	(categoryID)	references	categories	(CATEGORYID)
);
INSERT INTO Products (ProductID, ProductName, CategoryID, Price, manufactured) VALUES
(1, 'Bambola', 1, 19.99, 'mattel'),
(2, 'Set di costruzioni', 9, 29.99,'fisher price'),
(3, 'Macchinina telecomandata', 2, 49.99,'gig'),
(4, 'Puzzle', 7, 14.99,'hasbro'),
(5, 'Peluche', 1, 9.99,'preziosi'),
(6, 'Trenino giocattolo', 9, 39.99,'chicco'),
(7, 'Kit artistico', 7, 24.99,'hachette'),
(8, 'Gioco da tavolo', 7, 34.99,'lisciani'),
(9, 'Robot programmabile', 2, 59.99,'gig'),
(10, 'Pistola ad acqua', 1, 12.99,'preziosi'),
(11, 'Bicicletta senza pedali', 6, 79.99,'atala'),
(12, 'Set da giardinaggio', 8, 19.99,'brico'),
(13, 'Kit scientifico', 8, 29.99,'national geographic'),
(14, 'Cucina giocattolo', 1, 49.99,'preziosi'),
(15, 'Animali di plastica', 1, 6.99,'gig'),
(16, 'Aereo radiocomandato', 2, 69.99,'hasbro'),
(17, 'Kit di magia', 10, 22.99,'de agostini'),
(18, 'Camion dei pompieri', 1, 54.99,'preziosi'),
(19, 'Droni per principianti', 2, 89.99,'dji'),
(20, 'Kit di perline', 4, 16.99,'stroili');

CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT,
    Quantity INT,
    SaleDate DATE,
    RegionID INT,
    foreign key (ProductID) references products(ProductID),
    foreign key	(RegionID)	references	regions(regionID)
);

INSERT INTO Sales (SaleID, ProductID, Quantity, SaleDate, RegionID) VALUES
(1, 1, 5, '2024-02-01', 1),
(2, 3, 3, '2024-02-02', 2),
(3, 5, 2, '2024-02-03', 1),
(4, 2, 4, '2024-02-04', 3),
(5, 7, 1, '2024-02-05', 2),
(6, 10, 6, '2024-02-06', 10),
(7, 9, 3, '2024-02-07', 1),
(8, 4, 2, '2024-02-08', 2),
(9, 8, 4, '2024-02-09', 1),
(10, 12, 1, '2024-02-10', 5),
(11, 14, 3, '2024-02-11', 8),
(12, 15, 2, '2024-02-12', 1),
(13, 17, 4, '2024-02-13', 3),
(14, 19, 1, '2024-02-14', 16),
(15, 20, 3, '2024-02-15', 1),
(16, 6, 2, '2024-02-16', 4),
(17, 11, 5, '2024-02-17', 5),
(18, 13, 3, '2024-02-18', 1),
(19, 16, 2, '2024-02-19', 7),
(20, 18, 4, '2024-02-20', 2);


/*Svolgimento Query Richieste. 
Esercizio1 -Verificare che i campi definiti come PK siano univoci. 
Le chiavi primarie sono, per definizione, univoche e non possono contenere valori duplicati.*/

SELECT
count(CategoryID),
count(DISTINCT CategoryID)
FROM categories
AS catComparation;

SELECT 
	count(regionID),
    count(DISTINCT regionID)
FROM regions
as RegionComparation;

SELECT 
	count(saleID),
    count(DISTINCT	saleID)
FROM sales;

SELECT 
	count(productID),
    count(DISTINCT productID)
FROM products;

/*Esercizio2 - Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/

SELECT
products.ProductID,
    products.ProductName,
    YEAR(sales.SaleDate) as FatturatoAnno,
    SUM(sales.Quantity * products.price) AS EntrateTotali
    from products
    join sales on products.ProductID = sales.ProductID
    group by
		products.ProductID,
        products.ProductName,
        YEAR(sales.SaleDate)
    ORDER BY products.ProductID, FatturatoAnno;
    
    /* Esercizio3 - Esporre il fatturato totale per stato per anno.
    Ordina il risultato per data e per fatturato decrescente.*/
    select 
YEAR	(sales.saledate) as VenditeAnno, regions.RegionName as Stato, SUM(sales.Quantity * products.price)
AS EntrateTotali
from sales
JOIN products on sales.ProductID =products.ProductID
JOIN regions on sales.RegionID = Regions.RegionID
group by YEAR(sales.SaleDate), regions.regionName
order by VenditeAnno ASC, EntrateTotali DESC;

/*4 Qual è la categoria di articoli maggiormente richiesta dal mercato?*/

select
     CategoryName,
     SUM(sales.Quantity) as TotaleQuantita
     from products
     join categories on products.CategoryID = categories.CategoryID
     join sales on products.ProductID = sales.ProductID
     group by CategoryName
     order by TotaleQuantita DESC
	limit 1;
    
   /*Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
	--PRIMO APPROCCIO */
    
    select ProductName from products
    where products.ProductID NOT IN(SELECT ProductID from sales);
    
    /*-- SECONDO APPROCCIO; Ho pensato di usare NOT EXISTS che risulta una subquery che verifica se esistono righe nella tabella Sales con lo stesso ProductID del prodotto corrente.
    Se non esistono vendite per quel prodotto, la subquery non restituisce alcun risultato, e quindi il prodotto viene incluso nell'elenco finale.
    Se le tabelle sono grandi e ci interessa ottimizzare le performance, il secondo approccio con NOT EXISTS è generalmente preferibile, non in questo caso.*/
    
    SELECT products.ProductName
    from products
    where not exists(
    select 	1
    from sales
    where sales.productID =products.productID);
    
-- NON RISULTANO ESSERCI PRODOTTI INVENDUTI

-- 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT products.ProductName, 
MAX(sales.SaleDate) as piuRecente
from products
join sales on products.ProductID = sales.ProductID
group by products.ProductName;
    
    
    
    
    













    

